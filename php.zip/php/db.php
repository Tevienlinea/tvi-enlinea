<?php
 header("Access-Control-Allow-Origin: *");
 mysql_connect("localhost","root","123456789");
 mysql_select_db("phonegap_demo");
?>